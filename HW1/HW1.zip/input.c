// Chris Fietkiewicz (cxf47)
// Asks for user input
#include <stdio.h>

int main() {
	int  number;
	printf("Type an integer: ");
	scanf("%d", &number);
	printf("The number you typed was %d.\n", number);
	return 0;
}
