// Chris Fietkiewicz (cxf47)
// Infinite while loop
#include <stdio.h>

int main() {
	printf("Looping\n");
	while(1) {
	}
}

